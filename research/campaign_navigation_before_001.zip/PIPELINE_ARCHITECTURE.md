# Mechanome: research pipeline and persistent operation

**Checkpoint, 29 September:** [final numerical attempt 3](NONLINEAR_NUMERICAL_FINDINGS_003.md) completed all 26 solves but failed the unchanged physical residual gate. The numerical branch is closed; no K/K3 result was accepted. Separately, [analytic inverse stability](NONLINEAR_INVERSE_STABILITY_FINDINGS.md) shows that source recovery cannot have a uniform Lipschitz bound near flatness when balanced load is unknown. The [known-load comparison](KNOWN_LOAD_RECOVERY_FINDINGS.md) now proves a uniform near-flat recovery bound for compatible complete profiles when spatial load is fixed and known; current public tables do not supply those controls.

The [geometry transfer comparison](GEOMETRY_TRANSFER_FINDINGS.md) finds that the descriptive ranking depends on the target line and inclusion policy: flexible has the lowest primary equal-line mean error, while constant area wins for held-out U2OS and overall when flagged sites are included. The [tracking validator repair](TRACKING_METRIC_FINDINGS.md) passed 15 tests with one tracked movie. The [synthetic dimming result](SYNTHETIC_DIMMING_FINDINGS.md) retains its [execution overrun](synthetic_dimming_execution_audit.json). [NEXT_CYCLE.md](NEXT_CYCLE.md) now calls for a campaign synthesis and one prioritized evidence-gap decision. The yeast motion, Myo1E acquisition and completed analytic/numerical branches remain stopped. No biological mechanism has been selected.

**Checkpoint: 29 September 2026 (UTC).** This guide describes the system we actually
use, the research it has produced, and the parts that remain demonstrations.

The campaign asks what public clathrin data can distinguish about pit formation.
A coordinating agent selects a bounded question, specialists investigate it,
and independent review determines what can be retained. Files preserve the
result and next decision so a later run can continue after a gap or restart.

## 1. Overall architecture

```mermaid
flowchart TD
    User[User goals and latest steering] --> Lead[One coordinating lead in this task]
    Timer[Codex heartbeat requested every 30 minutes] --> Resume[Read saved direction and reconcile existing work]
    Resume --> Lead
    State[(Campaign files and dated progress)] --> Resume
    Lead --> Contract[Register question, assumptions, ownership and stopping rule]
    Contract --> Source[Source or data specialist]
    Contract --> Theory[Theory or numerical specialist]
    Source --> Evidence[Owned artifacts, calculations and provenance]
    Theory --> Evidence
    Evidence --> Review[Independent specialist review]
    Review --> Decide[Lead accepts, corrects, narrows or stops]
    Decide -->|Useful follow-up fits remaining budget| Contract
    Decide --> Checkpoint[Save findings, dispositions and next decision]
    Checkpoint --> State
    Checkpoint --> Notify[Notify for meaningful findings or required input]
```

These are roles, not permanent processes. A cycle can use fewer specialists or
several of the same specialty. Reviews can begin in parallel from a fresh brief;
the final decision checks the actual artifacts. The lead must change direction
when evidence warrants it. The repeating prompt starts that process; it does
not prescribe the same scientific task every time.

## 2. Where the research has taken us

```mermaid
flowchart TD
    Goal[Clathrin pit formation: what can we distinguish?] --> Data[Public-data and measurement audits]
    Goal --> Model[Explicit mechanics and synthetic tests]
    Data --> Caps[LocMoFit static cap geometry]
    Caps --> Ranking[Descriptive held-out geometry ranking]
    Caps --> Limits[Missing uncertainty and geometry limitations]
    Data --> Tracks[DASC and Shape2Fate track or metadata contracts]
    Data --> Controls[Bucher and Saleem control assessment]
    Controls --> Stop[Source inference or figure reproduction stopped]
    Model --> CapModel[Spherical-cap compensation and conditional rank]
    CapModel --> Full[Surrounding membrane and bounded solver checks]
    Full --> Observation[Finite-window cap observation check]
    Full --> Linear[Linear curvature-load ambiguity]
    Linear --> Nonlinear[Exact nonlinear source compensation]
    Nonlinear --> Unique[Conditional compact-source uniqueness]
    Unique --> Actual[Actual local stationary profiles with ordered slopes]
    Actual --> Attempt[Attempt1 stopped: output-handling bug]
    Attempt --> Repair[Reviewed code repair]
    Repair --> Attempt2[Attempt 2: 26 converged solves, physical residual failed]
    Attempt2 --> Diagnose[Saved-polynomial derivative diagnosis]
    Diagnose --> Ready[Final mesh preflight accepted after interruption]
    Ready --> Final[Attempt 3: physical residual failed; numerical branch closed]
    Actual --> Conditioning[Unknown load: inverse bound diverges near flatness]
    Conditioning --> Known[Known spatial load: uniform near-flat recovery bound]
    Known --> LimitsKnown[Public cap tables lack required profiles and controls]
    LimitsKnown --> Actin[Actin prediction reviewed; code metadata inventory queued]
    Limits --> Boundary[No biological mechanism selected yet]
    Tracks --> Boundary
    Stop --> Boundary
    Observation --> Boundary
```

| Line of work | What we have learned | Boundary |
| --- | --- | --- |
| Static cap tables | Across 23 file/cell groups in three cell lines, a flexible geometry reference has the best average held-out score, followed by constant area and constant curvature | Population prediction does not establish a single pit's trajectory or cause |
| Measurement audit and adapter cleanup | Missing uncertainty is explicit; raw and corrected cohorts are distinct; legacy fits require exploratory opt-in | Shared fitted variables and absent covariance prevent calibrated mechanics inference; 58.28% of corrected caps overhang the shallow graph model |
| Other public datasets and controls | Track/metadata contracts and public EM files were checked | Missing measurement controls prevent source separation; unresolved Bucher workbook-to-caption counts stop figure reproduction |
| Cap and full-membrane mechanics | Conditional compensation, rank and passive-shape results; numerical and observation-map errors were found and corrected | Results depend on the stated model, controls and sampled regimes |
| Linear source separation | Complete ideal shape constrains a combination of preferred curvature and load; tension changes alone preserve unrestricted ambiguity | Restricting source templates can restore rank without assuring useful precision |
| Exact nonlinear mechanics | The compensating load depends on slope; actual local stationary profiles meet the compact-source uniqueness condition | Flat profiles remain ambiguous; finite-amplitude numerics, stability and noise precision remain open |

Read [FINDINGS.md](FINDINGS.md) for the evidence boundaries and
[INDEX.md](INDEX.md) for designs, code, outputs and reviews. The latest theorem
is in [KNOWN_LOAD_RECOVERY_FINDINGS.md](KNOWN_LOAD_RECOVERY_FINDINGS.md).
It is a model-conditional research result, with no claim of established novelty
or a demonstrated biological mechanism.

The local existence and slope-ordering gate is proved within the registered
model. Numerical attempt1 stopped after one solver call at an output-handling
bug; no usable profile or gate result was saved. The failed source and empty
checkpoint are retained. After reviewed repair, attempt 2 completed 26 solves
but failed the independent physical equation residual check. The lead stopped
that attempt, suppressed the downstream diagnostic, then registered a separate
saved-polynomial analysis. It traced the dominant residual to derivative
inconsistency and proposed one fixed mesh refinement. The final numerical attempt then completed all 26 solves but missed the unchanged residual gate by a factor of 1.27 to 1.77. The lead closed the branch at its three-attempt limit. [NEXT_CYCLE.md](NEXT_CYCLE.md) records the next distinct question.
The preparation survived an observed runtime interruption; saved drafts and review
corrections were reconciled, then synthetic checks passed without BVP execution.
This is an example
of results changing the next decision within a cycle. It does not confirm the
theorem numerically or demonstrate uninterrupted operation.

## 3. What runs each cycle

1. **Resume:** read the latest user direction, campaign state, task register and
   progress. Record actual start time separately from scheduled delivery.
2. **Reconcile:** inspect previous workers and unfinished processes. An expired
   time budget or missing response does not prove an operation stopped.
3. **Choose:** identify the smallest informative question; state alternatives,
   expected outcomes, input provenance, checks and a stopping condition.
4. **Collaborate:** assign disjoint file ownership to at most three active
   specialists alongside the lead. Share intermediate findings when useful.
5. **Review and steer:** inspect evidence, resolve corrections and preserve
   negative or inconclusive results. Continue useful authorized follow-up within
   the same cycle when the previous gate is complete and budget remains.
6. **Checkpoint:** save results, dispositions, actual observed times, outstanding
   work, stop reason and the next executable decision.

A cycle targets at most 20 minutes, with time reserved for checkpointing. The
protocol allows at most three new specialists per cycle and three attempts per
logical task. Those limits guide the lead; they are not hard timing guarantees
implemented by the offline controller.

| Role | Requested profile | Responsibility |
| --- | --- | --- |
| Lead | Astra, xhigh | Select questions, coordinate, check evidence and maintain direction |
| Source specialist | Terra, medium | Primary papers, public data, provenance and measurement contracts |
| Numerical specialist | Terra, high | Bounded computations and implementation checks |
| Theory specialist | Sol, high | Derivations, counterexamples and explicit assumptions |
| Independent reviewer | Sol, high | Challenge the result, inspect evidence and preserve objections |

These are configured requests. The heartbeat inherits this task's settings;
its scheduler does not independently attest the lead model. Direct API spending
is zero: research uses supported subscription tools and local computation.

## 4. What persists, and where

| Record | What it preserves |
| --- | --- |
| [campaign.json](campaign.json) | Charter, limits, current decision and dated execution state |
| [NEXT_CYCLE.md](NEXT_CYCLE.md) | Exact next scientific action and what must not be reopened |
| [AGENT_LOOP.md](AGENT_LOOP.md) | Ownership, profiles, steering priority and stopping protocol |
| [agent_tasks.json](agent_tasks.json) | Task/attempt identities, owned files, execution and review dispositions |
| [PROGRESS.md](PROGRESS.md) | Dated activity, reasoning, alternatives, corrections and stop reasons |
| `*_design.json` | Fixed model/data assumptions, expected outcomes and acceptance checks |
| Theory, source, findings and review notes | Separate derivation, evidence, synthesis and challenge |
| Results, scripts and `*_manifest.json` | Reproducible computation and artifact identity through hashes |
| `metadata/` | Public source locators, access records and input provenance |
| [README.md](README.md), [INDEX.md](INDEX.md), [REPRODUCE.md](REPRODUCE.md) | Human-readable navigation and verification instructions |

Persistence has three levels: an **attempt** records bounded execution; a
**campaign** connects attempts across restarts; the **project** retains methods,
code and findings across campaigns. The roadmap's four-hour, 24-hour, 72-hour
and multiweek horizons are operating targets, not demonstrated uninterrupted uptime.

Markdown/JSON records are updated by the lead. The progress log is append-only
by convention, not an immutable database. Hashes detect changed bytes, not false
scientific claims. Local files persist without a Git push; that does not make
them a remote backup. The app's heartbeat configuration lives separately from
the repository, so copying the repository alone does not recreate its schedule.

On restart: read saved direction, reconcile unfinished work, preserve interrupted
attempts, then resume or register the next bounded action. Never duplicate an
operation whose execution status is unknown.

## 5. Does the 30-minute loop interfere with steering?

The saved automation is active and requests delivery every 30 minutes into this
same task. It is a recurring wake-up. Scheduled delivery, active computation,
queued work and a dated checkpoint are four different states.

Local-file scheduled work requires the computer to be on and the app running;
same-chat scheduled tasks return to the existing conversation. See the official
[Codex scheduling documentation](https://learn.chatgpt.com/docs/automations?surface=app).
Delivery time is not evidence of continuous activity. Reboots, unavailable tools
and subscription limits can leave gaps.

There is a real **priority risk** if a repeated research prompt is treated as a
fresh plan after the user has changed direction, or if the saved next step is
stale. We have not established that the 30-minute interval drops user messages,
creates overlapping leads, or has caused a scheduler fault. At this checkpoint,
the three research specialists had completed; no second coordinating lead was
observed in the current collaboration roster.

The operating rule is explicit: **latest applicable user steering takes priority
over the queued research step**. Record a changed objective before dispatching
more research. Finish an active requested deliverable, checkpoint existing work,
and do not let a heartbeat reset scope. Here, the architecture document and the
steering question took priority over starting the next scientific stage.

Changing cadence alone would not enforce that rule. The current protection is
lead behavior plus saved state; there is no live transactional priority queue
or proven scheduler-level mutual-exclusion mechanism in this repository.

## 6. The separate offline persistence controller

The repository also contains a Python controller in
[mechanome/research](../mechanome/research/). It is a foundation and restart demo;
it does not run the live subscription-agent campaign above.

```mermaid
flowchart LR
    Charter[Offline charter and task contract] --> Acquire[Acquire fenced lead ownership]
    Acquire --> Decide[Record decision and queued task]
    Decide --> Start[Start bounded attempt]
    Start --> Check[Run local deterministic check]
    Check --> Finish[Store result and hashed artifact]
    Finish --> Audit[Export audit]
    DB[(SQLite and artifact directory)] --- Acquire
    DB --- Decide
    DB --- Start
    DB --- Finish
    Restart[New process resumes saved state] --> Acquire
```

[contracts.py](../mechanome/research/contracts.py) defines offline charters,
tasks and distinct execution/outcome/quality fields.
[controller.py](../mechanome/research/controller.py) supplies SQLite transactions,
fenced lead ownership, stable task identities, attempt limits, immutable event
records, artifact hash checks and cost/reservation bookkeeping. Unknown execution
blocks replacement until reconciled. Valid negative outcomes can be retained.

[demo.py](../mechanome/research/demo.py) demonstrated separate-process
`checkpointed -> complete -> already_complete`: one attempt, eight recorded
events, zero API cost. It runs a fixed local analytic self-check. It does not
launch Codex agents, schedule heartbeats or select new research directions.
`quality="valid"` is a caller assertion, not an automatic scientific review.
Cost bookkeeping is not a provider billing limiter. Back up its SQLite database
and artifact directory together; see [REPRODUCE.md](REPRODUCE.md).

Connecting the live agent workflow to these transactional controls, building a
durable claim graph, and testing long-duration recovery end to end remain future
integration work. The current campaign does not claim those safeguards already
operate underneath its Markdown/JSON records.

## 7. How this relates to the scientific software

The broader codebase exposes two pipelines:

```text
curvo.analyze.analyze(movie, question)
    pixels -> geometry -> posterior -> mechanism -> report

curvo.orchestrator.search(case)
    propose -> validate -> evaluate -> refine -> record
```

Those are existing software paths, not the sequence proved successful on the
current public datasets. Our campaign audits what their inputs and outputs can
support and adds bounded analyses where needed. It has not demonstrated calibrated
force recovery from the public cap tables. See [CODEBASE.md](../CODEBASE.md) for
implementation navigation and the campaign's findings for current scientific permission.
