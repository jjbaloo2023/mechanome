# Clathrin research checkpoint

**Checkpoint, 29 September:** [final numerical attempt 3](NONLINEAR_NUMERICAL_FINDINGS_003.md) completed all 26 solves but failed the unchanged physical residual gate. The numerical branch is closed; no K/K3 result was accepted. Separately, [analytic inverse stability](NONLINEAR_INVERSE_STABILITY_FINDINGS.md) shows that source recovery cannot have a uniform Lipschitz bound near flatness when balanced load is unknown. The [known-load comparison](KNOWN_LOAD_RECOVERY_FINDINGS.md) now proves a uniform near-flat recovery bound for compatible complete profiles when spatial load is fixed and known; current public tables do not supply those controls.

The [geometry transfer comparison](GEOMETRY_TRANSFER_FINDINGS.md) finds that the descriptive ranking depends on the target line and inclusion policy: flexible has the lowest primary equal-line mean error, while constant area wins for held-out U2OS and overall when flagged sites are included. The [tracking validator repair](TRACKING_METRIC_FINDINGS.md) passed 15 tests with one tracked movie. The [synthetic dimming result](SYNTHETIC_DIMMING_FINDINGS.md) retains its [execution overrun](synthetic_dimming_execution_audit.json). [NEXT_CYCLE.md](NEXT_CYCLE.md) now calls for a campaign synthesis and one prioritized evidence-gap decision. The yeast motion, Myo1E acquisition and completed analytic/numerical branches remain stopped. No biological mechanism has been selected.

**Reviewed through 29 September 2026 (UTC).** The campaign has a descriptive result
from public cap-fit tables, conditional mechanics results, and a reviewed
software boundary for exploratory fits. It does not yet identify a biological
mechanism or calibrate force from those tables.

[Pipeline architecture and persistent operation](PIPELINE_ARCHITECTURE.md) explains the full workflow, research branches, agent roles, restart behavior and steering priority.

## Read in this order

1. [Findings](FINDINGS.md): what the evidence supports, what failed, and what is still missing.
2. [Study index](INDEX.md): grouped links to each design, implementation, result, figure and review.
3. [Reproduce and verify](REPRODUCE.md): offline checks, external inputs, and frozen-run conventions.
4. [Assessment](ASSESSMENT.md): the detailed theory/data decision and remaining gaps.
5. [Next decision](NEXT_CYCLE.md): the next bounded question and closed-branch rules.

The latest theory milestone constructs [actual local stationary
profiles](NONLINEAR_EXISTENCE_FINDINGS.md) that meet the earlier compact-source
uniqueness criterion. Their slope ordering holds across the source disk for
sufficiently small amplitude. [Numerical attempt1](NONLINEAR_NUMERICAL_FINDINGS.md) stopped at an output-handling
bug after one solver call, with no usable profile saved. The [corrected harness](NONLINEAR_NUMERICAL_REPAIR_FINDINGS.md) passed independent
review and synthetic preflight. [Attempt 2](NONLINEAR_NUMERICAL_FINDINGS_002.md) then completed all 26 solves but failed the physical residual gate. A [saved-polynomial diagnosis](NONLINEAR_RESIDUAL_POSTMORTEM.md) identifies derivative inconsistency; [final attempt 3](NONLINEAR_NUMERICAL_FINDINGS_003.md) also failed physical validation and closes the computational branch. Practical precision and
stability remain unresolved. The [Bucher
inclusion check](BUCHER_INCLUSION_FINDINGS.md) is complete: its sample-count
mapping remains unresolved and published-figure reproduction is stopped.
The earlier [linear result](LOAD_IDENTIFIABILITY_FINDINGS.md) remains valid
within its declared model. The latest completed
implementation is the [LocMoFit adapter and consumer
cleanup](LOCMOFIT_ADAPTER_CLEANUP.md). Missing uncertainty is explicit, raw and
corrected cohorts are distinct, and the two legacy static fitting consumers
require exploratory opt-in. These changes do not validate earlier biological
interpretations or the generic inverse pipeline.

## Where things live

| Location | Purpose |
| --- | --- |
| This directory's study notes, scripts, JSONs, figures and synthetic states | Reviewed scientific evidence and retained attempts; navigate through the study index |
| `*_frozen_*`, `*_before_*`, numbered result/record directories | Historical source, designs and outputs; a stored file is not automatically an accepted result |
| `metadata/` | Source inventories, access records, locators and checksums; downloaded payloads stay outside Git |
| [PROGRESS.md](PROGRESS.md), [agent_tasks.json](agent_tasks.json) | Dated activity, result dispositions, corrections and execution limitations |
| [campaign.json](campaign.json), [NEXT_CYCLE.md](NEXT_CYCLE.md), [AGENT_LOOP.md](AGENT_LOOP.md) | Current direction and subscription-driven operating protocol |
| [mechanome/research](../mechanome/research/) | Separate offline SQLite controller and restart demo |
| [validation/realdata](../validation/realdata/), [tests](../tests/) | Dataset adapters, exploratory consumers and regression checks |

Original evidence paths remain stable because code, manifests and reviews refer
to them. Rejected attempts are retained and labeled in the index; generated
caches and downloaded payload copies are ignored. Git preserves the exact bytes
of the research archive and the adapter files covered by its hash manifest.

## Operation and its limits

The active research workflow uses a coordinating Codex task and bounded
subscription subagents. Heartbeats request another cycle; they do not establish
continuous execution. The progress log distinguishes observed work, scheduling
gaps, stopped runs and queued decisions. Direct API spending remains zero.

The Python controller is an **offline persistence demonstration**. Its flow is
`acquire_lead -> decide -> start -> finish`; it records attempts, reservations,
fenced ownership and hashed artifacts. Unknown execution blocks replacement,
and valid negative outcomes are retained. It does not launch the subscription
agents, choose research questions, enforce provider budgets or run a service.
`quality="valid"` is a trusted caller assertion. SQLite and its artifact directory
must be backed up together. See the reproduction guide for its two-process demo.

The older [scientific reference](../RESEARCH.md) and [manuscript](../MANUSCRIPT.md)
contain historical demonstrations. Use this checkpoint's findings and reviews
for the current public-data claim boundary.
