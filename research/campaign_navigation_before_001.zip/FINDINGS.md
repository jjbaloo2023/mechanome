# Findings at the reviewed checkpoint

**Checkpoint, 29 September:** [final numerical attempt 3](NONLINEAR_NUMERICAL_FINDINGS_003.md) completed all 26 solves but failed the unchanged physical residual gate. The numerical branch is closed; no K/K3 result was accepted. Separately, [analytic inverse stability](NONLINEAR_INVERSE_STABILITY_FINDINGS.md) shows that source recovery cannot have a uniform Lipschitz bound near flatness when balanced load is unknown. The [known-load comparison](KNOWN_LOAD_RECOVERY_FINDINGS.md) now proves a uniform near-flat recovery bound for compatible complete profiles when spatial load is fixed and known; current public tables do not supply those controls.

The [geometry transfer comparison](GEOMETRY_TRANSFER_FINDINGS.md) finds that the descriptive ranking depends on the target line and inclusion policy: flexible has the lowest primary equal-line mean error, while constant area wins for held-out U2OS and overall when flagged sites are included. The [tracking validator repair](TRACKING_METRIC_FINDINGS.md) passed 15 tests with one tracked movie. The [synthetic dimming result](SYNTHETIC_DIMMING_FINDINGS.md) retains its [execution overrun](synthetic_dimming_execution_audit.json). [NEXT_CYCLE.md](NEXT_CYCLE.md) now calls for a campaign synthesis and one prioritized evidence-gap decision. The yeast motion, Myo1E acquisition and completed analytic/numerical branches remain stopped. No biological mechanism has been selected.

The strongest empirical result is a **descriptive ranking of deposited cap geometry**. The mechanics work establishes **conditional behavior and identifiability limits of specified synthetic models**. Neither line of evidence currently selects a biological mechanism, estimates force from the public data, or establishes how one pit changes over time. This page is a reading guide to the preserved study records; [INDEX.md](INDEX.md) links their designs, code, results, figures and reviews. [ASSESSMENT.md](ASSESSMENT.md) records the current evidence boundary.

## What the data support

Across 23 held-out file/cell groups in three cell lines from the S-BIAD566 processed spherical-cap tables, a flexible angle-to-curvature reference has the lowest average error, followed by strict constant area and then strict constant curvature. Each group is predicted using other groups in its own cell line. The ordering survives the recorded filtering and sensitivity checks, though some individual groups favor constant area. A synthetic population with constant curvature within every pit produces the same kind of ranking when sampling phase and pit identity covary. The fitted cap variables share a fit, and per-site covariance is unavailable. Thus the ranking describes cross-cell prediction of curated static fits; it does not establish a trajectory or its cause. See [geometry results](GEOMETRY_RESULTS.md), [independent review](INDEPENDENT_REVIEW.md), and [final disposition](REVIEW_DISPOSITION.md).

A stricter [whole-cell-line transfer comparison](GEOMETRY_TRANSFER_FINDINGS.md) now limits that ranking: constant area beats flexible for held-out U2OS in the primary and raw-nonnegative cohorts, and beats flexible in the equal-line mean when flagged sites are included. Constant curvature has the largest mean error in every held-out-line/policy fold. These are descriptive point estimates with no calibrated significance claim. The 27-fit comparison and independent review are complete; this branch is closed.

Public-data audits also establish narrower contracts. Shape2Fate tracking references have observed track IDs over frames 0–119, but do not supply complete lifetimes or curvature. The DASC raw-movie metadata map conditions, dates and cells, while processed traces and calibrated detection response are missing. The AP2 contrast is parked as a physical-mechanism test; a fixed downstream score alone cannot resolve condition-dependent missed or excluded structures. See [assessment](ASSESSMENT.md), [annotation review](ANNOTATION_REVIEW.md), and [DASC decision](DASC_OBSERVATION_DECISION.md). These are evidence-availability findings, not null biological results.

## What the models support

The implemented zero-line-tension spherical cap has an exact force–tension compensation family at fixed area when coat and force share the declared ramp, even with a prescribed changing rigidity. Under shared curvature, force and tension, two distinct known areas and two distinct known rigidity values can remove that particular ambiguity given enough nonzero, unclipped matched states; fixed rigidity still leaves curvature and force combined. An unknown rigidity scale or area-dependent inputs can restore ambiguities. These are structural statements under declared controls, not noisy-image recovery guarantees. See [cap findings](CAP_FINDINGS.md) and [two-area findings](TWO_AREA_FINDINGS.md).

Including the surrounding membrane preserves a decreasing **apex curvature** across sampled passive patch sizes in a small-slope calculation; the depth response depends on its reference and is not globally monotone. A bounded passive axisymmetric solver agrees with the shallow reference. Its material-area coordinate repair resolves a preserved node-limit failure, and a later sampled mild-to-moderate area test retains the negative apex ordering. These calculations are force-free and do not establish branch uniqueness, stability, scission or a molecular explanation. Pointwise apex curvature, coat average and a finite-window fitted cap curvature are different quantities. The corrected synthetic finite-window study preserves the sampled ordering, with fit values that depend on window and weighting. See [full shape](FULL_SHAPE_FINDINGS.md), [axisymmetric validation](AXISYMMETRIC_FINDINGS.md), [coordinate repair](AXISYMMETRIC_RHO_FINDINGS.md), [passive area](PASSIVE_AREA_FINDINGS.md), and [cap observation](CAP_OBSERVATION_FINDINGS.md).

## What remains stopped

The public LocMoFit tables provide processed cap fits without the localization likelihood inputs or per-site covariance needed for a calibrated mechanical comparison. In the retained corrected cohort, 58.28% of caps overhang the shallow graph surrogate. A fitted area–curvature slope at fixed cap angle also follows the fitting geometry itself. The reviewed adapter now marks missing uncertainty as null, keeps its historical raw default cohort, exposes a separate corrected cohort, and requires explicit exploratory opt-in for two legacy fitting consumers. Their scores remain conditional diagnostics and cannot authorize a decisive mechanism verdict. See [adapter cleanup](LOCMOFIT_ADAPTER_CLEANUP.md) and [review](LOCMOFIT_ADAPTER_REVIEW.md).

Historical attempts remain available with their dispositions. The first finite-window cap-fit run had an incorrect coordinate inversion and is rejected; only attempt 2 supports its findings. The highest-amplitude case in the tight shallow axisymmetric refinement hit its node limit; the later coordinate repair addresses that bounded case. The original two-area figure used an incorrect cutoff label; the corrected v2 figure is the one to interpret. None of these preserved outputs silently becomes accepted evidence. [INDEX.md](INDEX.md) points to the specific records.

## Latest full-membrane result

In the declared shallow-membrane model, complete ideal shape determines only
`kappa*Delta c + f`. A change in coat curvature can be exactly compensated by a
balanced normal load; changing tension alone at fixed rigidity leaves that
ambiguity intact. Independently prescribed Gaussian source templates have rank
two. At one preregistered configuration, apex curvature and edge-referenced
depth also give rank two, but their response columns are nearly antiparallel
(angle sine 0.0227). No calibrated observation precision follows. A prospective
route requires an independent traction map, or distinct known rigidities with
invariant source fields and calibrated profiles. See the [findings](LOAD_IDENTIFIABILITY_FINDINGS.md)
and [independent review](LOAD_IDENTIFIABILITY_REVIEW.md).

## Latest experimental-control assessment

The two-study [reviewed assessment](INDEPENDENT_CONTROLS_FINDINGS.md) found
insufficient controls for source separation. Bucher provides public cellular EM
area/class tables; Saleem provides a GUV tether-calibration precedent. Neither
currently closes the curvature/load observation contract.

The subsequent [Bucher workbook audit](BUCHER_EM_CONTRACT.md) verified both small
EM files and found that the shock workbook itself contains both experimental
arms. Its eight membrane groups contain fewer area entries than the published
Fig. 7 sample counts. This is an unresolved inclusion/mapping discrepancy, not
a biological effect or a claim that the paper is wrong. The [bounded inclusion
check](BUCHER_INCLUSION_FINDINGS.md) is now complete: numeric/header/coverage
checks pass, but package metadata and the named supplement do not explain the
counts. Published-figure reproduction is stopped; no effect was estimated.

## Latest nonlinear mechanics result

Under the exact axisymmetric graph energy, the balanced load needed to hide a
preferred-curvature change depends on the membrane slope. The shallow rule is
not a universal nonlinear source transformation. The [exact criterion](NONLINEAR_SOURCE_FINDINGS.md)
states when one correction can preserve two specified stationary profiles.
Flat profiles remain ambiguous at every tension, so this is not global
identifiability or empirical force recovery. Source coordinates, load work,
boundaries and the joint small-source limit are explicit and independently
reviewed. No solver or fit ran.

The [compact-source analysis](NONLINEAR_UNIQUENESS_FINDINGS.md) now proves a
sufficient uniqueness criterion from normalized slopes, with the support-boundary
and regular-origin requirements explicit. Equal-slope intervals in actual
common-load profiles must be flat, including annuli. The genuine flat ambiguity
remains. The [actual-profile existence result](NONLINEAR_EXISTENCE_FINDINGS.md) now
constructs such a pair locally for a small smooth compact curvature source and
zero load at tensions one and two. An exponentially weighted vector-field
argument supplies exact decaying stationary branches; positive screened linear
responses and a uniform remainder give strict slope ordering through the source
disk. This supplies a realizable example within the model, not stability or
practical precision. The finite-amplitude numerical checks below are a separate stage; they do not change the analytic theorem.

## Latest numerical execution

[Attempt1](NONLINEAR_NUMERICAL_FINDINGS.md) stopped after one solver call returned,
when output serialization accessed the wrong object. No usable profile, solver
status or acceptance metric was saved. Independent review also identified a
mislabeled linear-control path and incomplete checks before those paths ran.
This is a retained implementation failure, not a null physical result or a
contradiction of the local theorem. [Code repair and preflight review](NONLINEAR_NUMERICAL_REPAIR_FINDINGS.md) are
complete. [Attempt 2](NONLINEAR_NUMERICAL_FINDINGS_002.md) completed all 26 solves, but all 12 fine nonlinear profiles failed the physical residual gate despite solver status 0. K was suppressed. The [saved-coefficient diagnosis](NONLINEAR_RESIDUAL_POSTMORTEM.md) attributes the dominant defect to interpolation derivatives and proposes one fixed mesh refinement under unchanged scientific limits. [Resumed preparation and independent preflight](NONLINEAR_MESH_PREFLIGHT_FINDINGS_RESUMED.md) were accepted. [Final attempt 3](NONLINEAR_NUMERICAL_FINDINGS_003.md) completed 26 solves but again failed physical validation; all three attempts are now closed. The analytic
[cubic compatibility prediction](NONLINEAR_NUMERICAL_ASYMPTOTIC.md) remains
unverified numerically. See [NEXT_CYCLE.md](NEXT_CYCLE.md).
