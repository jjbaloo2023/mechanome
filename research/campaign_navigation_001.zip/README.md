# Clathrin research campaign

**Reviewed checkpoint: 29 September 2026.** We have descriptive results from
public geometry tables, conditional mechanics results, and tested observation
software. We have not selected a biological mechanism or recovered forces from
these public data. The latest geometry comparison shows that the preferred
curve changes with the held-out cell line and inclusion policy.

## Start here

1. [Findings](FINDINGS.md): the evidence, its limits, and what would change the conclusion.
2. [Assessment](ASSESSMENT.md): competing explanations, data requirements and branch decisions.
3. [Pipeline architecture](PIPELINE_ARCHITECTURE.md): how one lead and bounded specialists resume, review and steer the work.
4. [Study index](INDEX.md): original designs, code, results, figures, reviews and failed attempts.
5. [Reproduce and verify](REPRODUCE.md): input provenance, checks and protected historical outputs.
6. [Next decision](NEXT_CYCLE.md): the current executable direction and stopping rules.

## What belongs where

| Records | Purpose |
| --- | --- |
| Study notes, scripts, results and figures linked from the index | Evidence, assumptions, interpretation and independent challenge |
| Designs and hash manifests | Registered limits and exact artifact identity |
| [Progress](PROGRESS.md) and [task register](agent_tasks.json) | Actual observed activity, ownership, corrections and dispositions |
| [Campaign](campaign.json), next decision and [agent protocol](AGENT_LOOP.md) | Current direction and operating limits |
| `metadata/` | Public locators, access records and checksums; downloaded caches are excluded from Git |
| [Offline controller](../mechanome/research/) | Separate SQLite persistence/restart demonstration |

Original study paths remain stable. Rejected and inconclusive attempts stay
available with their dispositions; they are not silently replaced by successful
runs. The earlier navigation pages are preserved in the [synthesis snapshot](campaign_navigation_before_001.zip).

The live campaign uses subscription tools and local computation with zero direct
API spending. A 30-minute heartbeat requests another bounded cycle. Scheduled
delivery, active work, queued work and a dated checkpoint are different states;
saved files do not demonstrate uninterrupted execution or a remote backup.

Older [research notes](../RESEARCH.md) and the [manuscript](../MANUSCRIPT.md)
contain historical demonstrations. Use the reviewed findings for current claim
boundaries. Publishing and Git pushes are outside this heartbeat's authorization.
